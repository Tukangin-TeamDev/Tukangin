'use client';
import ProfileView from '@/components/profile/ProfileView';

export default function ProfilePage() {
  return (
    <div className="container py-8">
      <ProfileView />
    </div>
  );
}
