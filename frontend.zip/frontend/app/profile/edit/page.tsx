'use client';
import ProfileEditForm from '@/components/profile/ProfileEditForm';

export default function ProfileEditPage() {
  return (
    <div className="container py-8">
      <ProfileEditForm />
    </div>
  );
}
