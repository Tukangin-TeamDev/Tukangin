'use client';

export default function ProviderEarningsPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Pendapatan</h1>
      <p className="text-gray-600">
        Lacak dan kelola semua pendapatan Anda dari layanan yang telah diberikan.
      </p>
      {/* TODO: Add earnings dashboard UI */}
    </div>
  );
}
