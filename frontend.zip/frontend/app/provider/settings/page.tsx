'use client';

export default function ProviderSettingsPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Pengaturan Akun</h1>
      <p className="text-gray-600">
        Kelola pengaturan akun, notifikasi, dan preferensi lainnya di sini.
      </p>
      {/* TODO: Add settings UI */}
    </div>
  );
}
