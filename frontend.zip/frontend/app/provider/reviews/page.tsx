'use client';

export default function ProviderReviewsPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Ulasan & Rating</h1>
      <p className="text-gray-600">
        Lihat semua ulasan dan rating yang diberikan oleh pelanggan Anda.
      </p>
      {/* TODO: Add reviews and ratings UI */}
    </div>
  );
}
