'use client';

export default function ActiveOrdersPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Pesanan Sedang Berjalan</h1>
      <p className="text-gray-600">
        Berikut adalah daftar pesanan yang sedang dalam proses pengerjaan.
      </p>
      {/* TODO: Add active orders list UI */}
    </div>
  );
}
