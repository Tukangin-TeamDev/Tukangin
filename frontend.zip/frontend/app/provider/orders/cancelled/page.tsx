'use client';

export default function CancelledOrdersPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Pesanan Dibatalkan</h1>
      <p className="text-gray-600">
        Berikut adalah riwayat pesanan yang dibatalkan, baik oleh Anda maupun oleh pelanggan.
      </p>
      {/* TODO: Add cancelled orders list UI */}
    </div>
  );
}
