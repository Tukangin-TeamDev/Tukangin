'use client';

export default function NewOrdersPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Pesanan Baru</h1>
      <p className="text-gray-600">
        Berikut adalah daftar pesanan baru yang masuk dan menunggu konfirmasi Anda.
      </p>
      {/* TODO: Add new orders list UI */}
    </div>
  );
}
