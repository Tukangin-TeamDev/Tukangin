'use client';

export default function CompletedOrdersPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Pesanan Selesai</h1>
      <p className="text-gray-600">
        Berikut adalah riwayat pesanan yang telah berhasil Anda selesaikan.
      </p>
      {/* TODO: Add completed orders list UI */}
    </div>
  );
}
