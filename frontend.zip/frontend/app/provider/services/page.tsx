'use client';

export default function ProviderServicesPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Layanan Saya</h1>
      <p className="text-gray-600">
        Kelola semua layanan yang Anda tawarkan kepada pelanggan. Anda dapat menambah, mengubah,
        atau menghapus layanan di halaman ini.
      </p>
      {/* TODO: Add service management UI */}
    </div>
  );
}
